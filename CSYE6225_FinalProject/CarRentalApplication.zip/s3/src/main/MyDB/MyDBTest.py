'''
Created on Nov 29, 2016

@author: Maansi
'''


import mysql.connector
import urllib
import webbrowser
import http.cookiejar
from requests import Request, Session

db= mysql.connector.connect(host="localhost:3306", user="root", passwd="root", db=cloud)

cur=db.cursor()

cur.execute("SELECT username, password FROM useraccount WHERE userid BETWEEN 1 AND 10")

data=cur.fetchall()

for row in data:
    login_data=urllib.request.urlencode({'username': row[3],'j_password':row[1]})
    url='http://localhost:8080/spring/'
    s=requests.session()
    requests.post(url,login_data)
    db.commit()
   
db.close()
    
    
